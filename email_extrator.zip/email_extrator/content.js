function extractEmails() {
    const emails = document.body.textContent.match(/\S+@\S+\.\S+/g);
    if (emails) {
        const uniqueEmails = new Set(emails.map(email => email.toLowerCase()));
        chrome.runtime.sendMessage({ emails: Array.from(uniqueEmails) });
    } else {
        chrome.runtime.sendMessage({ emails: [] });
    }
}
  
extractEmails();